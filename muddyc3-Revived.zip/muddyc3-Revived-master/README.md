This is a working POC the leaked MuddyC3 C2 . its include below fetaures right now : 
1) agent reconnect
2) load modules
3) send commands and recive results
4) create powershell payloads

check the article : https://shells.systems/reviving-leaked-muddyc3-used-by-muddywater-apt/

i will publish my new tool which created on top of muddyc3 soon.
